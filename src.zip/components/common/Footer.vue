<template>
	<footer>
		<p>copyRight Kwangwoon University DB_Project Team DB MANMAN</p>
	</footer>
</template>

<script>
export default {
	
}
</script>

<style scoped>
footer{border-top:1px solid #020202; text-align:center; font-size:16px; color:#41b883; margin:100px 0 0 0;}
</style>