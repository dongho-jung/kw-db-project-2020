<!-- 전체적으로 설계하는 부분--><!-- 프로젝트가 다루는 컴포넌트가 표시되는 Root 컴포넌트-->
<template>
  <div id="app">
    <Header />
    <router-view></router-view> <!-- -->
    <Footer />
    
  </div>

</template>

<script>
import Header from './components/common/Header';
import Footer from './components/common/Footer';
export default {
  name: 'app',
  components: {
    Header
    ,Footer
  }
}
</script>

<style>
html,body{padding:0; margin:0;}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: 'black';
  margin:0; padding:0;
}
</style>

