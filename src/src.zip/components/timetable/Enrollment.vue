<!-- 상단에 있는 수강 신청 누르면 나오는 페이지 -->

<template>
  <div class="Enrollment_part">
   <div class="Fbox1">
    <div class="Fbox11" align="center">All class
      <div class="Fbox111">
        <table border="1" bordercolor="black" width='560' height='580' align="center" font size="1em">
          <th width="220">Name</th><th width="120">Class Id</th><th width="160">Class Professor</th><th width="100">Period</th><th width="100">Place</th><th>Credit</th>
        </table>
      </div>

      <div class="Fbox112">
        <div style="overflow-x:auto; overflow-y:auto; height:280px;">
          <table border="1" bordercolor="black" width='560' height='580' text-align="center" font size="1em">
            <tr><td width="220">Data Structure</td><td width="120">H020-2-4181</td><td width="160">Lee Ki Hoon</td><td width="100">Mon1Tue2</td><td width="100">Sabit304</td><td>3</td></tr>
            <tr><td>Operation System</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
            <tr><td>Understanding of Music</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
            <tr><td>Understanding of Movie</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
            <tr><td>Algorithm</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
            <tr><td>DanceSport</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
            <tr><td>Read & Write</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
            <tr><td>Swimming</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
            <tr><td>DanceSport</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
            <tr><td>DanceSport</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
            <tr><td>DanceSport</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
            <tr><td>DanceSport</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
            <tr><td>DanceSport</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
            <tr><td>DanceSport</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
            <tr><td>DanceSport</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
            <tr><td>DanceSport</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
            <tr><td>DanceSport</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
            <tr><td>DanceSport</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
            <tr><td>DanceSport</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
            <tr><td>DanceSport</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
          </table>
        </div>
      </div>
    </div>

    <div class="Fbox12">
    </div>

    <div class="Fbox13">
      <div class="Fbox131">
        <div class="Fbox1311">
          <font size="3em" face="bold"><p>Class ID : </p></font>
        </div>
        <div class="Fbox1312">
          <p><input type="text" name="Class ID" size=50 style = "text-align:center;"></p>
        </div>
        <div class="Fbox1313">
          <p><input type="button" value="Search" size=70 style = "width:60pt;height:16pt;text-align:center;"></p>
        </div>
      </div>
      <div class="Fbox132" align="center">
        <font size="3em" face="bold"><p>Search Result</p></font>
      </div>
      <div class="Fbox133">
        <table border="1" bordercolor="black" width='560' height='580' align="center" font size="1em">
          <th width="220" height="30">Name</th><th width="120">Class Id</th><th width="160">Class Professor</th><th width="100">Period</th><th width="100">Place</th><th>Credit</th>
          <tr><td width="220">Data Structure</td><td width="120">H020-2-4181</td><td width="160">Lee Ki Hoon</td><td width="100">Mon1Tue2</td><td width="100">Sabit304</td><td>3</td></tr>
          
        </table>
      </div>
      <div class="Fbox134">
        <p><input type="button" value="Push" width=70 style = "width:260pt;height:20pt;text-align:center;"></p>
      </div>
    </div>
   </div>

   <div class="Fbox2">
     <div class="Fbox21">
        <div class="Fbox211">
          <div class="Pad">삭제
          </div>
          <div class="Fbox2111">
            <input type="button" value="Push" width=70 style = "text-align:center;">
          </div>
          <div class="Fbox2112">
            <input type="button" value="Push" width=70 style = "text-align:center;">
          </div>
          <div class="Fbox2113">
            <input type="button" value="Push" width=70 style = "text-align:center;">
          </div>
          <div class="Fbox2114">
            <input type="button" value="Push" width=70 style = "text-align:center;">
          </div>
          <div class="Fbox2115">
            <input type="button" value="Push" width=70 style = "text-align:center;">
          </div>
          <div class="Fbox2116">
            <input type="button" value="Push" width=70 style = "text-align:center;">
          </div>
          <div class="Fbox2117">
            <input type="button" value="Push" width=70 style = "text-align:center;">
          </div>
          <div class="Fbox2118">
            <input type="button" value="Push" width=70 style = "text-align:center;">
          </div>
        </div>
        <div class="Fbox212">
          <table border="1" bordercolor="black" width='560' height='580' align="center" font size="1em">
          <th width="100">Index</th><th width="260">Name</th><th width="160">Class Id</th><th width="160">Class Professor</th><th width="100">Period</th><th width="100">Place</th><th>Credit</th>
          <tr><td>1</td><td width="260">Data Structure</td><td width="160">H020-2-4181</td><td width="160">Lee Ki Hoon</td><td width="100">Mon1Tue2</td><td width="100">Sabit304</td><td>3</td></tr>
          <tr><td>2</td><td>Operation System</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
          <tr><td>3</td><td>Understanding of Music</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
          <tr><td>4</td><td>Understanding of Movie</td><td>H020-2-4181</td><td>Lee Ki Hoon</td><td>Mon1Tue2</td><td>Sabit304</td><td>3</td></tr>
          <tr><td>5</td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
          <tr><td>6</td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
          <tr><td>7</td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
          <tr><td>8</td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
            
        </table>
        </div>
     </div>

     <div class="Fbox22">
       <div class="Fbox221">
       </div>
       <div class="Fbox221">
         <font size="5em" face="bold"><p>Server Time : 09:59:58</p></font>
       </div>
       <div class="Fbox221">
         <input type="button" value="Enrollment all" width=70 style = "width:280pt; height:30pt; text-align:center;">
       </div>
       <div class="Fbox222">
         <input type="button" value="Go Back" width=70 style = "width:280pt; height:30pt; text-align:center;">
       </div>
     </div>
   </div>
  </div>
</template>

<script>
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
.button {
  color: black;
  padding: 7px 60px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  cursor: pointer;
}
table, th, td {
  border: 1px solid #bcbcbc;
}
table {
  text-align:center;
  width: 100%;
  height: 100%;
}
a{text-decoration:none; color:black}
.Enrollment_part > div {
  border-radius: 5px;
  background-color: white;
  border: 1px solid;
  padding: 1em;
}
.Enrollment_part{
  display: grid;
  grid-template-columns: 1fr;
  grid-template-rows: 400px 400px;
  grid-gap: 10px;
}
.Fbox1{
  display: grid;
  grid-template-columns: 5fr 1fr 5fr;
  grid-template-rows: 350px;
  grid-gap: 20px;
}
.Fbox11{
  display: grid;
  grid-template-rows: 3fr 7fr;
  grid-gap: 10px;
}
.Fbox111{
  border: 1px solid;
}
.Fbox112{
  display: grid;
  grid-template-columns: 1fr;
  grid-template-rows: 1fr;
  border: 1px solid;
}
.Fbox12{
  display: grid;
  grid-template-rows: 2fr 1fr 1fr 2fr;
  grid-gap: 20px;
  border: 1px solid;
}
.Fbox13{
  display: grid;
  grid-template-rows: 1fr 1fr 3fr 1fr;
  grid-gap: 10px;
  border: 1px solid;
}
.Fbox131{
  display: grid;
  grid-template-columns: 1fr 3fr 1fr;
  grid-gap: 10px;
  border: 1px solid;
}
.Fbox1311{
border: 1px solid;
}
.Fbox1312{
  border: 1px solid;
}
.Fbox1313{
  border: 1px solid;
}
.Fbox132{
  border: 1px solid;
}
.Fbox133{
  display: grid;
  grid-template-columns: 1fr;
  grid-template-rows: 1fr;
  border: 1px solid;
}
.Fbox134{
  border: 1px solid;
}
.Fbox2{
  display: grid;
  grid-template-columns: 7fr 3fr;
  grid-template-rows: 350px;
  grid-gap: 20px;
}
.Fbox21{
  display: grid;
  grid-template-columns: 1fr 10fr;
  grid-gap: 10px;
  border: 1px solid;
}
.Fbox211{
  display: grid;
  grid-template-rows: 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr;
  grid-gap: 1px;
  border: 1px solid;
  
}
.Fbox2111{
  border: 1px solid;
}
.Fbox2112{
  border: 1px solid;
}
.Fbox2113{
  border: 1px solid;
}
.Fbox2114{
  border: 1px solid;
}
.Fbox2115{
  border: 1px solid;
}
.Fbox2116{
  border: 1px solid;
}
.Fbox2117{
  border: 1px solid;
}
.Fbox2118{
  border: 1px solid;
}
.Fbox212{
  border: 1px solid;
}
.Fbox213{
  display: grid;
  grid-template-rows: 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr 1fr;
  grid-gap: 1px;
  border: 1px solid;
}
.Fbox2131{
  border: 1px solid;
}
.Fbox2132{
  border: 1px solid;
}
.Fbox2133{
  border: 1px solid;
}
.Fbox2134{
  border: 1px solid;
}
.Fbox2135{
  border: 1px solid;
}
.Fbox2136{
  border: 1px solid;
}
.Fbox2137{
  border: 1px solid;
}
.Fbox2138{
  border: 1px solid;
}
.Fbox212{
  border: 1px solid;
}
.Fbox22{
  display: grid;
  grid-template-rows: 1fr 1fr 1fr 1fr;
  grid-gap: 10px;
  border: 1px solid;
}
.Fbox221{
  border: 1px solid;
  
}
.Fbox222{
  border: 1px solid;
}
.Fbox223{
  border: 1px solid;
}
.Pad{
  border: 1px solid;
}
#wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>