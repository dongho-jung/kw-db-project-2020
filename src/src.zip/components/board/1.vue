<template>
  <div class="content">
    <div class="Pad">
    </div>

    <div class="box1">
      <div class="boxBorder">
        <h1>법과권리</h1>
      </div>

      <div class="box12">
        <div class="box121">
          <div class="box121n" align="left">
            <div class="boxPad20">
              <img alt="DB1" src="../../assets/User.png" height = "40" width="40">
            </div>
            <div class="boxPad15">
              <font size="3em">익명</font><br>
              <font size="2em">2021/11/23 15:18</font>
            </div>
            <div class="Pad">
            </div>
          </div>
          <div class="boxPad5" align="left">
            <font size="5em">법과권리</font>
          </div>
          <div class="boxPad5" align="left">
            <font size="3em">과제 여태 몇번 나갔나요?</font>
          </div>
          <div class="boxPad5" align="right">
            <font size="3em">Like 1 Hate 0 Comment 2</font>
          </div>
        </div>

        <div class="box12n">
          <div class="box12n1">
            <div class="box12n11">
              <div class="boxPad5">
                <img alt="DB1" src="../../assets/User.png" height = "20" width="20">
              </div>
              <div class="boxPad5" align="left">
                <font size="2em">익룡</font>
              </div>
            </div>
            <div class="box12n12">
              <div class="Pad">
              </div>
              <div class="boxPad5" align="left">
                <font size="2em">오늘 25번째 나갔어요</font>
              </div>
              <div class="boxPad5" align='right'>
                <a href="http://localhost:8080/#/board/hotlist">
                  <font size="1.5em">대댓글</font>
                </a>
              </div>
            </div>
          </div>

          <div class="box12n2">
            <div class="Pad">
            </div>
            <div class="boxPad5">└
              <img alt="DB1" src="../../assets/User.png" height = "20" width="20">
            </div>
            <div class="boxPad5">
              <font size="2em">(글쓴이)</font>
            </div>
            <div class="boxPad5" align='left'>
              <font size="2em">헉 감사합니다. 드랍해야지 ㅎㅎ</font>
            </div>
          </div>
        </div>

        <div class="box12n">
          <div class="box12n1">
            <div class="box12n11">
              <div class="boxPad5">
                <img alt="DB1" src="../../assets/User.png" height = "20" width="20">
              </div>
              <div class="boxPad5" align="left">
                <font size="2em">익룡</font>
              </div>
            </div>
            <div class="box12n12">
              <div class="Pad">
              </div>
              <div class="boxPad5" align="left">
                <font size="2em">법과 권리 너모 어려워요...</font>
              </div>
              <div class="boxPad5" align='right'>
                <a href="http://localhost:8080/#/board/hotlist">
                  <font size="1.5em">대댓글</font>
                </a>
              </div>
            </div>
          </div>

          <div class="box12n2">
            <div class="Pad">
            </div>
            <div class="boxPad5">└
              <img alt="DB1" src="../../assets/User.png" height = "20" width="20">
            </div>
            <div class="boxPad5">
              <font size="2em">(글쓴이)</font>
            </div>
            <div class="boxPad5" align='left'>
              <font size="2em">맞아요.. 그래서 전 드랍하려고요. 같이 하쉴?</font>
            </div>
          </div>
        </div>
        
        <div class="box123">
          <div class="boxPad">
            <img alt="DB1" src="../../assets/pencil.png" height = "30" width="30">
          </div>
          <div class="boxPad">
            <input type="text" name="Search" style = "width:360pt;height:20pt;text-align:left;">
          </div>
          <div class="boxPad">
            <input type="button" name="Search" value="Upload" style = "width:60pt;height:24pt;text-align:center;">

          </div>
        </div>
      </div>
    </div>

    <div class="box2">
      <div class="boxBorder">
        <h2>HOT게시판</h2>
      </div>
      <div class="box2n">
        <div class="boxPad15" align="left">
          <a href="http://localhost:8080/#/board/hotlist">
          <font size="2.8em">진짜 너무 한거 아니냐...</font>
          </a>
        </div>
        <div class="boxPad15" align="right">
          <font size="2em">11/23 09:13</font>
        </div>
      </div>
      <div class="box2n">
        <div class="boxPad15" align="left">
          <a href="http://localhost:8080/#/board/hotlist">
          <font size="2.8em">송라이팅1 수강생 여러분</font>
          </a>
        </div>
        <div class="boxPad15" align="right">
          <font size="2em">11/23 01:28</font>
        </div>
      </div>
      <div class="box2n">
        <div class="boxPad15" align="left">
          <a href="http://localhost:8080/#/board/hotlist">
          <font size="2.8em">오늘은 연평도 포격사건 10주기</font>
          </a>
        </div>
        <div class="boxPad15" align="right">
          <font size="2em">11/23 01:01</font>
        </div>
      </div>
      <div class="box2n">
        <div class="boxPad15" align="left">
          <a href="http://localhost:8080/#/board/hotlist">
          <font size="2.8em">짜잔</font>
          </a>
        </div>
        <div class="boxPad15" align="right">
          <font size="2em">11/22 20:46</font>
        </div>
      </div>
      <div class="boxPad15">
        <a href="http://localhost:8080/#/board/hotlist">
        <font size="2em">더보기</font>
        </a>
      </div>
      <div class="Pad">
      </div>
    </div>

    <div class="Pad">
    </div>
  </div>
</template>

<script>

</script>

<style>
.button {
  color: black;
  padding: 7px 60px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  cursor: pointer;
}

a{text-decoration:none; color:black}

.content > div {
  border-radius: 5px;
  background-color: white;
  padding: 1em;
}

.content{
  display: grid;
  grid-template-columns: 2fr 4fr 2fr 2fr;
  grid-template-rows: 900px;
  grid-gap: 10px;
}

.Pad{
  
}

.box{
  
}

.boxBorder{
  border: 1px solid;
}

.boxPad{
  padding:10px;
}

.boxPad5{
  padding:5px;
}

.boxPad15{
  padding:15px;
}

.boxPad20{
  padding:20px;
}

.boxPad25{
  padding:25px;
}


.boxPad15Border{
  padding:15px;
  border: 1px solid;
}

.boxMar{
  border: 1px solid;
  margin:5px;
}

.box1{
  display: grid;
  grid-template-rows: 1fr 9fr;
  grid-gap: 10px;
}

.box121n{
  display: grid;
  grid-template-columns: 1fr 2fr 7fr;
  grid-gap: 10px;
}

.box12{
  display: grid;
  grid-template-rows: 3fr 1fr 1fr;
}

.box121{
  display: grid;
  grid-template-rows: 2fr 3fr 2fr 1fr;
  grid-gap: 10px;
  border: 1px solid;
}

.box12n{
  display: grid;
  grid-template-rows: 3fr 2fr;
  border: 1px solid;
}

.box12n1{
  display: grid;
  grid-template-rows: 1fr 1fr;
}

.box12n11{
  display: grid;
  grid-template-columns: 1fr 15fr;
}

.box12n12{
  display: grid;
  grid-template-columns: 1fr 20fr 5fr;
}

.box12n2{
  display: grid;
  grid-template-columns: 2fr 3fr 3fr 25fr;
  padding: 2px;
}

.box123{
  display: grid;
  grid-template-columns: 2fr 12fr 3fr;
  border: 1px solid;
}

.box2{
  display: grid;
  grid-template-rows: 1fr 1fr 1fr 1fr 1fr 1fr 9fr;
  grid-gap: 0px;
}

.box2n{
  display: grid;
  grid-template-columns: 2fr 1fr;
  grid-gap: 1px;
  border: 1px solid;
}


#header, #nav, #section, #footer { text-align:center; }
#header, #footer { line-height:100px; }
#nav, #section { line-height:240px; }
</style>